#include <iostream>
#include <vector>
#include <map>
using namespace std;

//读取图
void getGraph(int** array,int num){
    for(int i=0;i<num;i++){
        for(int j =0;j<num;j++){
            cin>>array[i][j];
        }
    }
}

//计算一个节点的聚集系数
void getClusteringCoefficient(int** array,int num,int target){
    vector<int> friends ;
    //找出所有朋友
    for (int i = 0;i<num;i++){
        if (array[target][i] == 1){
            friends.push_back(i);
        }
    }
    int friendNum = int(friends.size());
    //总对数
    int all = (friendNum - 1) * friendNum / 2;
    int n = 0;
    for (int i = 0; i<friends.size() - 1; i++){
        int a1 = friends.at(i);
        for (int j = i+1;j<friends.size();j++){
            int a2 = friends.at(j);
            if(array[a1][a2] == 1){
                n++;
            }
        }
    }
    cout<<"节点"<<target<<"聚集系数:"<<n * 1.0/all<<endl;
}

//计算两节点的邻里重叠度
void getNeighborhoodOverlap(int** array,int num,int target1,int target2){
    int commonFriendNum = 0;//共同邻居
    int allFriends = 0;//总邻居
    map<int ,int> m;
    for (int i = 0; i < num; ++i) {
        //与二者均为邻居
        if(i!=target1&&i!=target2){
            if (array[target1][i] == 1 && array[target2][i] == 1){
                commonFriendNum++;
            }
            if((array[target1][i] == 1 || array[target2][i] == 1)&&m[i] == NULL){
                allFriends++;
                m[i] = 1;
            }
        }

    }
    if (allFriends == 0){
        cout<<target1<<"与"<<target2<<"的邻里重叠度为0"<<endl;
        m.clear();
    } else{
        cout<<target1<<"与"<<target2<<"的邻里重叠度为"<<commonFriendNum* 1.0/allFriends<<endl;
        m.clear();
    }
}

int main() {
    int nodesNum;
    //====================初始化数据===================
    cout<<"输入节点个数"<<endl;
    cin>>nodesNum;
    int ** array = new int*[nodesNum];
    for(int i=0;i<nodesNum;i++)
        array[i] = new int[nodesNum];
    cout<<"输入邻接矩阵"<<endl;
    //=======================读取数据==================
    getGraph(array,nodesNum);
    //========================计算聚集系数===============
    for (int i = 0; i < nodesNum; ++i) {getClusteringCoefficient(array,nodesNum,i);}
    //=========================邻里重叠度============
    for (int i = 0; i < nodesNum - 1; ++i) {
        for (int j = i + 1; j < nodesNum; ++j) {
            getNeighborhoodOverlap(array,nodesNum,i,j);
        }
    }
    //===========================释放空间=============
    for(int i=0;i<nodesNum;i++)
        delete []array[i];
    delete []array;
}
