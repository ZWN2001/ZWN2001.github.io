#include <iostream>
#include <vector>
#include <map>
#include <queue>
using namespace std;
//输入：给定m个人对n个项目按排序的投票。
//输出：
//1）确定其中是否隐含有孔多塞悖论（涉及到在有向图上尝试节点的拓扑排序）。
//2）如果没有，就直接给出群体序，如果有，就按照一个特定的属性序，指出哪些投票是不满足单峰性质的，认为它们是“废票”，
// 剔除后按照中位项定理给出群体排序。

void initVoteResult(map<int,int>& voteResult, int n){
    for (int i = 1; i < n; ++i) {
        for (int j = i+1; j <= n; ++j) {
            voteResult[i * 10 + j] = 0;
            voteResult[j * 10 + i] = 0;
        }
    }
}

bool testCondorcet(vector<vector<int>>& votes,int n,int m){
    map<int,int> voteResult;//计算两两项目之间的表决结果
    int result;
    initVoteResult(voteResult,n);

    //统计所有项目两两之间的表决数
    for (int i = 0; i < m; ++i) {
        for (int j = 0; j < n-1; ++j) {
            for (int k = j+1; k < n; ++k) {
                result = votes[i][j] * 10 + votes[i][k];
                voteResult[result] ++;
            }
        }
    }

    //初始化邻接矩阵
    int** adjacencyMatrix = new int*[n+1];
    for (int i = 0; i <= n; ++i) {
        adjacencyMatrix[i] = new int[n+1];
        for (int j = 0; j <= n; ++j) {
            adjacencyMatrix[i][j] = 0;
        }
    }

    //根据表决结果构造邻接矩阵，规定若 i>j则图中节点i指向j
    for (int i = 1; i < n; ++i) {
        for (int j = i + 1; j <= n; ++j) {
            int a = i * 10 + j;
            int b = j * 10 + i;
            if (voteResult[a]>voteResult[b]){//候选项i>j,图中由i指向j
                adjacencyMatrix[j][i] = 1;//这样每一行中1的个数就是对应行下标的入度
            } else{
                adjacencyMatrix[i][j] = 1;
            }
        }
    }

    //计算每个项目的入度
    map<int,int> inDegree;
    queue<int> topologyQueue;
    for (int i = 1; i <= n; ++i) {
        inDegree[i] = 0;
    }

    int count;
    for (int i = 1; i <= n ; ++i) {
        count = 0;
        for (int j = 1; j <= n ; ++j) {
            if (adjacencyMatrix[i][j] == 1){
                count++;
            }
        }
        inDegree[i] = count;
        if (inDegree[i] == 0){
            topologyQueue.push(i);
        }
    }

    //按照入度进行拓扑
    string  topologyResult;
    while (!topologyQueue.empty()){
        int zeroInDegreeNode = topologyQueue.front();
        topologyQueue.pop();
        topologyResult += (""+to_string(zeroInDegreeNode)+" ");
        for (int i = 1; i <= n; ++i) {
            if (adjacencyMatrix[i][zeroInDegreeNode] == 1){
                adjacencyMatrix[i][zeroInDegreeNode] = 0;
                inDegree[i]--;
                if (inDegree[i] == 0){
                    topologyQueue.push(i);
                }

            }
        }
    }

    //拓扑完成若还有节点有入度那么就一定存在环（孔多塞悖论）
    auto iter = inDegree.begin();
    while(iter != inDegree.end()) {
        if (iter->second != 0){
            cout<<"存在孔多塞悖论"<<endl;
            return true;
        }
        iter++;
    }
    cout<<"不存在孔多塞悖论，表决结果为："<<endl<<topologyResult<<endl;
    return false;
}

void merge(vector<int>& arr,int low,int mid,int high){
    //low为第1有序区的第1个元素，i指向第1个元素, mid为第1有序区的最后1个元素
    int i=low,j=mid+1,k=0;  //mid+1为第2有序区第1个元素，j指向第1个元素
    int *temp=new int[high-low+1]; //temp数组暂存合并的有序序列
    while(i<=mid&&j<=high){
        if(arr[i]<=arr[j]) //较小的先存入temp中
            temp[k++]=arr[i++];
        else
            temp[k++]=arr[j++];
    }
    while(i<=mid)//若比较完之后，第一个有序区仍有剩余，则直接复制到t数组中
        temp[k++]=arr[i++];
    while(j<=high)//同上
        temp[k++]=arr[j++];
    for(i=low,k=0;i<=high;i++,k++)//将排好序的存回arr中low到high这区间
        arr[i]=temp[k];
    delete []temp;//释放内存，由于指向的是数组，必须用delete []
}

void mergeSort (vector<int>& arr, int low,int high) {
    if(low>=high) { return; } // 终止递归的条件，子序列长度为1
    int mid =  low + (high - low)/2;  // 取得序列中间的元素
    mergeSort(arr,low,mid);  // 对左半边递归
    mergeSort(arr,mid+1,high);  // 对右半边递归
    merge(arr,low,mid,high);  // 合并
}

int getMiddle(vector<int>& fronts){
    mergeSort(fronts, 0, fronts.size());
    if (fronts.size() % 2 == 0){
        return fronts[fronts.size() / 2 - 1];
    } else{
        return fronts[fronts.size() / 2];
    }
}

void unimodal(vector<vector<int>>& votes,int n,int m){
    int unimodalPeopleNum = m;//记录有多少人满足单峰
    //判断每个人的投票是否满足单峰
    map<int,bool> hasUnimodal;
    int unimodal ;
    for (int i = 0; i <= m; ++i) {
        hasUnimodal[i] = true;
    }

    for (int i = 0; i < m; ++i) {
        unimodal = 0;
        for (int j = 0; j < n; ++j) {
            if ((j == 0 && votes[i][j] > votes[i][j + 1]) ||
            (j == n - 1 && votes[i][n - 1] > votes[i][n - 2]) ||
            (j != 0 && j != n-1 && votes[i][j] > votes[i][j - 1] && votes[i][j] > votes[i][j + 1])) {
                unimodal++;
            }
        }
        if (unimodal > 1) {
            cout << "第" << i << "个人的表决不满足单峰" << endl;
            hasUnimodal[i] = false;
            unimodalPeopleNum--;
        }
    }

    vector<vector<int>> votesAfterUnimodal;
    for (int i = 0; i < m; ++i) {
        if (hasUnimodal[i]){
            votesAfterUnimodal.push_back(votes[i]);
        }
    }

    vector<int> fronts;
    string unimodalResult;
    for (int j = 0; j < n; ++j) {
        fronts.clear();
        for (int i = 0; i < unimodalPeopleNum; ++i) {
            fronts.push_back(votesAfterUnimodal[i].front());
        }

        int middle = getMiddle(fronts);
        for (int i = 0; i < unimodalPeopleNum; ++i) {
            for (auto iter = votesAfterUnimodal[i].begin(); iter != votesAfterUnimodal[i].end(); iter++){
                if (*iter == middle){
                    votesAfterUnimodal[i].erase(iter);
                    break;
                }
            }
        }
        unimodalResult += (to_string(middle)+" ");
    }
    cout<<"剔除废票后的结果"<<unimodalResult<<endl;
}

int main() {
    int m = 3,n = 3;
    vector<vector<int>> votes;
    votes = {
            {1,2,3},
            {3,1,2},
            {2,3,1}
    };
    bool isC = testCondorcet(votes,n,m);
    if (isC){
        unimodal(votes,n,m);
    }
    return 0;
}
