#include <iostream>
#include <random>
using namespace std;

//nxn的随机网络
int** getRandomGraph(int n){
    random_device rd;
    default_random_engine gen = std::default_random_engine(rd());
    uniform_int_distribution<int> dis(0,n*n);
    int ** graph = new int* [n];

    for (int i = 0; i < n; ++i) {
        graph[i] = new int[n];
        graph[i][i] = 0;
        for (int j = i+1; j < n; ++j) {
            int random;
            random = dis(gen);
            if (random%20 == 1){
                graph[i][j] = 1;
            } else{
                graph[i][j] = 0;
            }
        }
    }
    for (int i = 1; i < n; ++i) {
        for (int j = 0; j < i; ++j) {
            graph[i][j] = graph[j][i];
        }
    }
    return graph;
}

//两个节点是否可能构成三元闭包
int canBuildRelation(int**& g,int m,int n){
    int count = 0;
    for (int i = 0; i < n; ++i) {
        if (g[m][i] == 1&&g[n][i]==1){
            count++;
        }
    }
    return count;
}

//模拟社会网络
int ** getSN(int n,int times){
    random_device rd;
    default_random_engine gen = std::default_random_engine(rd());
    uniform_int_distribution<int> dis(0,n*n);
    int ** graph = getRandomGraph(n);
    for (int i = 0; i < times; ++i) {
        for (int j = 0; j < n-1; ++j) {
            for (int k = j+1; k < n; ++k) {
                if (graph[j][k] != 1){
                    int fri = canBuildRelation(graph,j,k);
                    if (fri!=0){
                        int random = dis(gen);
                        int weight = n/fri;
                        if (random%weight==1){
                            graph[j][k] = 1;
                            graph[k][j] = 1;
                        }
                    }

                }
            }
        }
    }
    return graph;
}

//获取每个节点朋友个数
int * getFriendNum(int n,int **& g){
    int * friendNum = new int[n];
    int num = 0;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            if (g[i][j] == 1){
                num++;
            }
        }
        friendNum[i] = num;
        num = 0;
    }
    return friendNum;
}

//获取友谊悖论占比
double getFriendshipParadox(int**& g,int*& friendNum,int n){
    int count = 0;
    int fri_fri = 0;
    double result = 0;
    for (int i = 0; i < n; ++i) {
        //遍历节点i所有的朋友
        for (int j = 0; j < n; ++j) {
            if (g[i][j] ==1){
                count++;
                fri_fri+=friendNum[j];//朋友的朋友总数
            }
        }
        if (fri_fri>friendNum[i]*count){
            result++;
        }
    }
    return result/n;
}

void print2(int** & g,int n){
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            cout<<g[i][j]<<" ";
        }
        cout<<endl;
    }
    cout<<endl;
}
void print1(int* & g,int n){
        for (int j = 0; j < n; ++j) {
            cout<<g[j]<<" ";
        }
        cout<<endl;
    cout<<endl;
}
int main() {
    int n = 1024 ,times = 32;
    int ** g1 = getRandomGraph(n);
    int ** g2 = getSN(n,times);
    int* f1 = getFriendNum(n,g1);
    int* f2 = getFriendNum(n,g2);
    double  result1 = getFriendshipParadox(g1,f1,n);
    double  result2 = getFriendshipParadox(g2,f2,n);
    cout<<"随机图中的友谊悖论节点占比是"<<result1*100<<"%"<<endl;
    cout<<"社会网络中的友谊悖论节点占比是"<<result2*100<<"%"<<endl;
    return 0;
}
