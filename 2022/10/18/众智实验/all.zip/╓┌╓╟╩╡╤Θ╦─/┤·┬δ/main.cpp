#include <iostream>
#include <vector>
#include <queue>

using namespace std;

int times = 1;
vector<vector<int>> neighbors(10);//记录该人的邻居，避免重复计算邻居
vector<int> neighborsUsingNew(10);//使用新事物的邻居数
vector<int> usingNew;//记录有哪些节点选择使用新事物
queue<int> usingNewOnce;//记录每次扩散新加入的节点，便于优化性能

void printNewUsingMember(int node){
    cout<<"第"<<times<<"轮，节点"<<node<<"开始使用新事物"<<endl;
}
void printNewUsingOnceTime(){
    cout<<"======第"<<times<<"轮结束=========="<<endl;
    times++;
}
//输出的函数
void print2(vector<vector<int>>& g,int n){
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            cout<<g[i][j]<<" ";
        }
        cout<<endl;
    }
    cout<<endl;
}
void print1(vector<int>& g,int n){
    for (int j = 0; j < n; ++j) {
        cout<<g[j]<<" ";
    }
    cout<<endl;
    cout<<endl;
}

void initNeighbors(vector<vector<int>>& graph,int graphSize){
    for (int i = 0; i < graphSize; ++i) {
        for (int j = 0; j < graphSize; ++j) {
            if (graph[i][j] == 1){
                neighbors[i].push_back(j);//j是i的邻居
            }
        }
    }
    for (int i = 0; i < graphSize; ++i) {
        neighborsUsingNew[i] = 0;
    }

    for (int usingN : usingNew) {
        for (int j = 0; j < graphSize; ++j) {
            if (graph[usingN][j] == 1){
                neighborsUsingNew[j]++;
            }
        }
    }
}

void diffuseOnce(vector<vector<int>>& graph, vector<double>& threshold){
    //只有上次刚刚换用新事物的节点才会有可能对其邻居产生影响
    int n = usingNewOnce.size();
    for (int j = 0; j < n; ++j){
        int lastNewUser = usingNewOnce.front();
        cout<<"处理"<<lastNewUser<<"的邻居"<<endl;
        usingNewOnce.pop();
        for (int& i:neighbors[lastNewUser]) {
          //检查上一次新加入的使用新事物的人的邻居
                bool isUsingNew = false;
                for (int k : usingNew) {
                    if (k == i){
                        isUsingNew = true;  //这个邻居已经使用新事物了
                    }
                }
                if (!isUsingNew&&((neighborsUsingNew[i] * 1.0)/neighbors[i].size()) >= threshold[i]){//没有用新事物而且到达阈值的邻居
                    //加入采用新事物的行列
                    usingNew.push_back(i);
                    usingNewOnce.push(i);
                    printNewUsingMember(i);
                    //通知其邻居该人使用新事物了
                    for (int& k : neighbors[i]) {
                        neighborsUsingNew[k]++;
                    }
                }
        }
    }
    printNewUsingOnceTime();
}

int main(int argc, char *argv[]){
    int graphSize = 10;
    vector<vector<int>> graph = {
        {0,1,1,1,1,1,0,0,0,0},
        {1,0,1,1,0,0,0,0,0,0},
        {1,1,0,0,1,0,0,0,0,0},
        {1,1,0,0,0,1,1,0,0,0},
        {1,0,1,1,0,1,0,0,0,0},
        {1,0,0,1,1,0,0,1,0,0},
        {0,0,0,1,0,0,0,1,1,0},
        {0,0,0,0,0,1,1,0,0,1},
        {0,0,0,0,0,0,1,0,0,1},
        {0,0,0,0,0,0,0,1,1,0}
};
    vector<double> threshold = {0.8,0.4,0.1,0.7,0.4,0.5,0.3,0.4,0.1,0.1};
    vector<int> startNodes = {0};


    //初始时的所有起始节点一定是接受新事物的
    for (int & startNode : startNodes) {
        usingNew.push_back(startNode);
        usingNewOnce.push(startNode);//初始时认为上一轮扩散新加入的节点就是起始节点
    }

    initNeighbors(graph,graphSize);

    //每次有扩散新加入的节点，就再扩散一次
    while (!usingNewOnce.empty()){
        diffuseOnce(graph,threshold);
    }
    cout<<"扩散结束"<<endl;
    return 0;
}
