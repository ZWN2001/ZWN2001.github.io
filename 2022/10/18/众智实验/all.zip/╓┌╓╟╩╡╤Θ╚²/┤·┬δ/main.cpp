#include <iostream>
#include <vector>
#include <queue>

using namespace std;
void print2(vector<vector<int>> & g,int n){
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            cout<<g[i][j]<<" ";
        }
        cout<<endl;
    }
    cout<<endl;
}

void shrink(vector<vector<int>>& graph, vector<int>& allNodes){
    int n = allNodes.size();
    for (int i = 0; i < n; ++i) {//第i行
        if (allNodes[i] != 0){//第i行没被删掉
            for (int j = i + 1; j < n; ++j) {//该行第j个数，从i+1开始
                if (allNodes[j] != 0 && graph[i][j] == 1){//第j个数没被删且是正向边，进行合并（j并入i）
                    allNodes[j] = 0;//删掉j
                    for (int k = 0; k < n; ++k) {
                        if (k!=i && allNodes[k] != 0){//保证i这一列还是0，且还存在
                            if (graph[i][k] == 0&&graph[j][k]!=0){
                                graph[i][k] = graph[j][k];
                                graph[k][i] = graph[j][k];
                            }
                        }
                    }
//                    print1(allNodes,n);
//                    print2(graph,n);
                }
            }
        }
    }
}

bool hasSameLevelConnection(vector<vector<int>>& graph,vector<int>& nodes){
    int n = nodes.size();
    for (int i = 0; i < n - 1; ++i) {
        for (int j = i + 1; j < n; ++j) {
            if (graph[i][j] == -1){
                return true;
            }
        }
    }
    return false;
}

bool bfs(vector<vector<int>>& graph){
    int n = graph.size();
    queue<int> q;
    q.push(0);
    int lastLevel = 1,thisLevel = 0;//记录上一层和这一层的节点数
    while (!q.empty()){
        lastLevel--;
        int m = q.front();
        q.pop();
        for (int i = 0; i < n; ++i) {
            if (graph[m][i] == -1){
                q.push(graph[m][i]);
                thisLevel++;
            }
        }
        //同层的节点放到一个数组
        if (thisLevel > 1 && lastLevel == 0){//要保证上一层的点已经完全出队
            queue<int> q1(q);//拷贝
            vector<int> v(q1.size());
            for (int i = 0; i < q1.size(); ++i) {
                v[i] = q1.front();
                q1.pop();
            }
            if (hasSameLevelConnection(graph,v)){
                return true;
            }
            //这一层判断完成
            lastLevel = thisLevel;
            thisLevel = 0;
        }
    }
    return false;
}

int main() {
//    vector<vector<int>> graph = {{0,-1,0,1,0,1},
//                                 {-1,0,1,0,0,0},
//                                 {0,1,0,-1,0,0},
//                                 {1,0,-1,0,1,1},
//                                 {0,0,0,1,0,1},
//                                 {1,0,0,1,1,0}
//    };
//    vector<vector<int>> graph = {{0,1,-1,0},
//                                 {1,0,0,1},
//                                 {-1,0,0,-1},
//                                 {0,1,-1,0},
//    };
    vector<vector<int>> graph = {{0,-1,-1,0,-1},
                                 {-1,0,0,-1,1},
                                 {-1,0,0,1,0},
                                 {0,-1,1,0,-1},
                                 {-1,1,0,-1,0},
    };
    int n = graph.size();
    //初始的时候把所有节点放入集合
    vector<int> allNodes(n,1);
    //进行简化
    shrink(graph,allNodes);
    int count = 0;//简化完成的图中有多少节点
    for (int i = 0; i < n; ++i) {
        if (allNodes[i] == 1){
            count++;
        }
    }
    //最后节点少于2个，必然没有
    if (count == 2 ||count == 1 || count == 0){
        cout<<"不存在负向边圈"<<endl;
        return 0;
    }
    //简化后的矩阵
    vector<vector<int>> shrinked(count);
    for (int i = 0; i < count; ++i) {
        vector<int> a(count,0);
        shrinked[i] = a;
    }
    int u = 0,v;//新矩阵的第u行，第v列
    for (int i = 0; i < n; ++i) {
        v = 0;
        if (allNodes[i] == 1){
            for (int j = 0; j < n; ++j) {
                if (allNodes[j] == 1){
                    shrinked[u][v] = graph[i][j];
                    shrinked[v][u] = graph[i][j];
                    v++;
                }
            }
            u++;
        }
    }
    cout<<"简化所有正向边后的简单图："<<endl;
    print2(shrinked,count);

    //使用bfs判断是否有负向边圈
    if (bfs(graph)){
        cout<<"存在负向边圈"<<endl;
    } else{
        cout<<"不存在负向边圈"<<endl;
    }
    return 0;
}