package com.example.starchat.provider;

import androidx.core.content.FileProvider;

public class DemoProvider extends FileProvider {
}
