package com.example.starchat.broadcastReceiver;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;

import android.net.NetworkInfo;
import android.net.wifi.p2p.WifiP2pDevice;
import android.net.wifi.p2p.WifiP2pManager;

import android.text.TextUtils;

import androidx.core.app.ActivityCompat;

import com.example.starchat.activity.MainActivity;
import com.example.starchat.myInterface.WifiChannelListener;

import java.util.ArrayList;
import java.util.List;


/**
 * WiFi P2p广播接收器
 * 监听wifi p2p状态，设备列表变化，连接状态变化和设备信息变化
 */
public class WifiBroadcastReceiver extends BroadcastReceiver {

    private final WifiP2pManager mWifiP2pManager;
    private final WifiP2pManager.Channel mChannel;
    private final WifiChannelListener mWifiChannelListener;

    public WifiBroadcastReceiver(WifiP2pManager wifiP2pManager, WifiP2pManager.Channel channel, WifiChannelListener wifiChannelListener) {
        mWifiP2pManager = wifiP2pManager;
        mChannel = channel;
        mWifiChannelListener = wifiChannelListener;
    }

    public static IntentFilter getIntentFilter() {
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION);
        intentFilter.addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION);
        intentFilter.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION);
        intentFilter.addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION);
        return intentFilter;
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        if (!TextUtils.isEmpty(intent.getAction())) {
            switch (intent.getAction()) {
                //用于指示wifi p2p是否可用
                case WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION:
                    int state = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1);
                    if (state == WifiP2pManager.WIFI_P2P_STATE_ENABLED) {
                        mWifiChannelListener.wifiP2pEnabled(true);
                    } else {
                        mWifiChannelListener.wifiP2pEnabled(false);
                        List<WifiP2pDevice> wifiP2pDeviceList = new ArrayList<>();
                        mWifiChannelListener.onPeersAvailable(wifiP2pDeviceList);
                    }
                    break;
                //对等节点列表变化
                case WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION:
                    if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(new MainActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
                        return;
                    }
                    mWifiP2pManager.requestPeers(mChannel, peers -> mWifiChannelListener.onPeersAvailable(peers.getDeviceList()));
                    break;
                //wifi p2p连接状态发生变化
                case WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION:
                    final NetworkInfo networkInfo = intent.getParcelableExtra(WifiP2pManager.EXTRA_NETWORK_INFO);
                    if (networkInfo.isConnected()) {
                        mWifiP2pManager.requestConnectionInfo(mChannel, mWifiChannelListener::onConnectionInfoAvailable);
                    } else {
                        mWifiChannelListener.onDisconnection();
                    }
                    break;
                //设备信息发生变化
                case WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION:
                    mWifiChannelListener.onSelfDeviceAvailable(intent.getParcelableExtra(WifiP2pManager.EXTRA_WIFI_P2P_DEVICE));
                    break;
            }
        }
    }
}
