package com.example.starchat.util;

/**
 * 服务器端口
 */
public class SocketUtil {
    public static final int PORT = 10000;
}
