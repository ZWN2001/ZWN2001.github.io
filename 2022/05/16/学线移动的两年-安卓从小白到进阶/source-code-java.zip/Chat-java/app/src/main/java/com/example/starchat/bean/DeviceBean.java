package com.example.starchat.bean;

/**
 * 设备信息类
 */
public class DeviceBean {
    public int deviceType;
    public String deviceName;
    public String deviceStatus;
}
