package top.ss007.bridge.additives;

public interface ICoffeeAdditives {
    void addSomething();
}
