import AirConditioners.AirConditioner;
import Refrigerators.Refrigerator;

public class DemoMain {
    public static void main(String[] args) {
        Hasen hasen = new Hasen();
        Refrigerator hasenRefrigerator = hasen.buildRefrigerator();
        AirConditioner hasenAirConditioner = hasen.buildAirConditioner();
        hasenRefrigerator.use();
        hasenAirConditioner.use();

        Meidi meidi = new Meidi();
        Refrigerator meidiRefrigerator = meidi.buildRefrigerator();
        AirConditioner meidiAirConditioner = meidi.buildAirConditioner();
        meidiRefrigerator.use();
        meidiAirConditioner.use();

    }
}
