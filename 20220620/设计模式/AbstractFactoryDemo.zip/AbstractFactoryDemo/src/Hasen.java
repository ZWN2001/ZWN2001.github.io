import AirConditioners.AirConditioner;
import AirConditioners.HasenAirConditioner;
import Refrigerators.HasenRefrigerator;
import Refrigerators.Refrigerator;

public class Hasen extends AbstractFactory{

    @Override
    public AirConditioner buildAirConditioner() {
        return new HasenAirConditioner();
    }

    @Override
    public Refrigerator buildRefrigerator() {
        return new HasenRefrigerator();
    }
}
