import AirConditioners.AirConditioner;
import AirConditioners.MeidiAirConditioner;
import Refrigerators.MeidiRefrigerator;
import Refrigerators.Refrigerator;

public class Meidi extends AbstractFactory{

    @Override
    public AirConditioner buildAirConditioner() {
        return new MeidiAirConditioner();
    }

    @Override
    public Refrigerator buildRefrigerator() {
        return new MeidiRefrigerator();
    }
}
