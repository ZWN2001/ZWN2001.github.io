package AirConditioners;

public abstract class AirConditioner {
    public void use(){}
}
