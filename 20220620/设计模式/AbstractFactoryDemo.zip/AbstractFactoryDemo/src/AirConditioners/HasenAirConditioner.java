package AirConditioners;

public class HasenAirConditioner extends AirConditioner{
    public HasenAirConditioner(){
        System.out.println("建造海信空调");
    }

    @Override
    public void use() {
        super.use();
        System.out.println("使用海信空调");
    }
}
