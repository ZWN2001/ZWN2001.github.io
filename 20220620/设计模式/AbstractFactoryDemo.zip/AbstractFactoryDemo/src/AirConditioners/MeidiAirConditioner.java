package AirConditioners;

public class MeidiAirConditioner extends AirConditioner{
    public MeidiAirConditioner(){
        System.out.println("建造美的空调");
    }

    @Override
    public void use() {
        super.use();
        System.out.println("使用美的空调");
    }
}
