package Refrigerators;

public class HasenRefrigerator extends Refrigerator{
    public HasenRefrigerator(){
        System.out.println("建造海信冰箱");
    }
    @Override
    public void use() {
        super.use();
        System.out.println("使用海信冰箱");
    }
}
