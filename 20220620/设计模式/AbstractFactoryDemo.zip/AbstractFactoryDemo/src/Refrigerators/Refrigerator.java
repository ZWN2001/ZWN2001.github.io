package Refrigerators;

public abstract class Refrigerator {
    public void use(){}
}
