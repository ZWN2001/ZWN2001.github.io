package Refrigerators;

public class MeidiRefrigerator extends Refrigerator{
    public MeidiRefrigerator(){
        System.out.println("建造美的冰箱");
    }

    @Override
    public void use() {
        super.use();
        System.out.println("使用美的冰箱");
    }
}
