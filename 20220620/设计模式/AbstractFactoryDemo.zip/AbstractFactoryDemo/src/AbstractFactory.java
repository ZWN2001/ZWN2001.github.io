import AirConditioners.AirConditioner;
import Refrigerators.Refrigerator;

public abstract class AbstractFactory {
    public abstract AirConditioner buildAirConditioner();
    public abstract Refrigerator buildRefrigerator();
}